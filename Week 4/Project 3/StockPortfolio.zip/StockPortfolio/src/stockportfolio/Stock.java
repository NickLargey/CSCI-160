/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockportfolio;

import java.util.ArrayList;

/**
 *
 * @author Nick Largey
 */
public class Stock {

    private String stockName;
    private double[] quotes;
    private double lowestStockPrice;
    private double highestStockPrice;
    private double netStockChange;
    private double avgStockPrice;
    private double stdDeviation;
    private int longestUpwardTrend;
    private double bestGrowthRate;

    /**
     * constructor #1.
     */
    public Stock() {
        this.stockName = "";
        this.quotes = new double[quotes.length];
    }

    /**
     * constructor #2.
     *
     * @param name - the name of the company's stock.
     * @param quotesList - Array of stock prices.
     */
    public Stock(String name, double[] quotesList) {
        this.stockName = name;
        this.quotes = quotesList;

    }

    /**
     * Calculates the lowest stock price for the stock object.
     */
    private void lowestStockPrice() {
        this.lowestStockPrice = Double.MAX_VALUE;

        for (int i = 0; i < quotes.length; i++) {
            if (quotes[i] < lowestStockPrice) {
                lowestStockPrice = quotes[i];
            }
        }
    }

    /**
     * calculates the highest Stock price for the stock object.
     */
    private void highestStockPrice() {
        this.highestStockPrice = Double.MIN_VALUE;

        for (double highQuote : quotes) {
            if (highQuote > highestStockPrice) {
                highestStockPrice = highQuote;
            }
        }
    }

    /**
     * calculates the price difference from the latest to earliest quote.
     */
    private void netStockChange() {

        this.netStockChange = quotes[quotes.length - 1] - quotes[0];

    }

    /**
     * calculates the average of the stock quotes.
     */
    private void avgStockPrice() {
        double averagePrice = 0.0;

        for (int i = 0; i < quotes.length; i++) {
            averagePrice += quotes[i];
        }
        this.avgStockPrice = averagePrice / quotes.length;
    }

    /**
     * calculates the standard deviation of the stock object.
     */
    private void stdDeviation() {
        double n = quotes.length;
        double sum = 0;
        double mean = 0;

        for (int i = 0; i < n; i++) {
            sum += quotes[i];
        }
        mean = sum / n;

        sum = 0;

        for (int i = 0; i < n; i++) {
            sum += Math.pow((quotes[i] - mean), 2);

        }

        mean = sum / n;

        this.stdDeviation = Math.sqrt(mean);

    }

    /**
     * finds the longest growth trend of the stock object.
     */
    private void longestUpwardTrend() {
        int longestRun = 0;
        int counter = 0;

        for (int i = 1; i < quotes.length; i++) {
            if (quotes[i - 1] < quotes[i]) {
                counter++;
            }
            if (counter > longestRun) {
                longestRun = counter;
            }
        }
        this.longestUpwardTrend = longestRun;
    }

    /**
     * finds the growth rate of all collected upward trends then calculates the
     * best rate. UNSURE OF HOW TO DO THIS AT THIS TIME.
     */
    private void bestGrowthRate() {
        //--- implment method ---
        if (longestUpwardTrend > 0) {
            this.bestGrowthRate = 0.0;
        } else {
            this.bestGrowthRate = 0;
        }
    }

    @Override
    public String toString() {
        return String.format("%-20s %8.2f %8.2f %8.2f %8.2f %8.2f %3d %8.2f\n",
                this.stockName,
                this.lowestStockPrice,
                this.highestStockPrice,
                this.netStockChange,
                this.avgStockPrice,
                this.stdDeviation,
                this.longestUpwardTrend,
                this.bestGrowthRate);
    }

    /**
     * run method to call each calculation.
     */
    public void run() {
        lowestStockPrice();
        highestStockPrice();
        netStockChange();
        avgStockPrice();
        stdDeviation();
        longestUpwardTrend();
        bestGrowthRate();
    }

    public static void main(String[] args) {
        Stock stock = new Stock();
        stock.run();

    }

    /**
     * Unit test for the Stock class. expected output is below
     *
     * @param args the command line arguments
     */
//    public static void main(String[] args){
//        double [] quotes = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
//        String name = "A";
//        Stock s = new Stock(name, quotes);
//        s.run();
//        System.out.println(s);                
//    }

    /*
A                         10.00 100.00   90.00   55.00  28.72   9    10.00  
     */
}
