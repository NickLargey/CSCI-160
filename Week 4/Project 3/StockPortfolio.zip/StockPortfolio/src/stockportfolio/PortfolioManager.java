/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockportfolio;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Nick Largey
 */
public class PortfolioManager {

    private final Portfolio portfolio = new Portfolio();

    /**
     * Reads in file of companies and their associated stock quotes.
     *
     * @param fileName - File to be read.
     * @throws FileNotFoundException
     * @throws IOException
     */
    public void readStockFile(String fileName) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        if (br.readLine() == null) {
            System.out.println("The file you chose is empty");
            System.exit(0);
        }

        try {
            Scanner f = new Scanner(new FileReader(fileName));

            while (f.hasNext()) {
                String stockName = f.next();
                double[] stockQuotes = new double[0];
                while (f.hasNextInt() || f.hasNextDouble()) {
                    stockQuotes = Arrays.copyOf(stockQuotes, stockQuotes.length + 1);
                    if (f.hasNextInt()) {
                        stockQuotes[stockQuotes.length - 1] = (double) f.nextInt();
                    } else {
                        stockQuotes[stockQuotes.length - 1] = f.nextDouble();
                    }

                }

                Stock stock = new Stock(stockName, stockQuotes);
                portfolio.addStock(stock);
            }

            f.close();

        } catch (FileNotFoundException ex) {
            // we catch it and print an error message
            System.out.println("File " + fileName + " not found");
            // and exit in a controlled manner
            System.exit(1);
        }
    }

    /**
     * Helper method to call readStockFile() and print formatted calculations.
     *
     * @param fileName - File to be read.
     * @throws IOException
     */
    public void run(String fileName) throws IOException {

        readStockFile(fileName);
        System.out.print(portfolio.toString());
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.err.println("usage: progname inputFile");
            System.exit(1);
        }

        PortfolioManager driver = new PortfolioManager();
        driver.run(args[0]);
    }

}
