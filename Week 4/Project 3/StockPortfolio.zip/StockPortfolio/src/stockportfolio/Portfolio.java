/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stockportfolio;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nick Largey
 */
public class Portfolio {

    private ArrayList<Stock> stockQuotes = new ArrayList<Stock>();

    /**
     * Constructor #1.
     */
    public Portfolio() {
        this.stockQuotes = new ArrayList<>();
    }

    /**
     * Constructor #2
     *
     * @param stockQuotes - ArrayList of stock objects.
     */
    public Portfolio(ArrayList<Stock> stockQuotes) {
        this.stockQuotes = stockQuotes;

    }

    /**
     * Adds stock object to stockQuotes ArrayList
     *
     * @param s - stock object to be added.
     */
    public void addStock(Stock s) {
        this.stockQuotes.add(s);
    }

    @Override
    public String toString() {
        String results = "";
        for (Stock quote : stockQuotes) {
            quote.run();
            results += quote.toString();
        }

        return String.format("%-20s %8s %8s %8s %8s %8s %3s %8s\n",
                "Company",
                "Low",
                "High",
                "Net",
                "Avg",
                "Dev",
                "Lng",
                "BestTrRt" + "\n" + results);
    }

    /**
     * Unit test for Portfolio class expected output is below
     *
     * @param args
     */
//    public static void main(String[] args){
//        Portfolio portfolio = new Portfolio();
//        double [] quotes = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
//        String name = "A";
//        portfolio.addStock(new Stock(name, quotes));
//        name = "B";
//        double[] quotes2 = {100, 90, 80, 70, 60, 50, 40, 30, 20, 10};
//        portfolio.addStock(new Stock(name, quotes2));
//        System.out.println(portfolio);
//    }
/*
Company                     Low     Hi     Net     Ave    Dev  Lng  BestTrRt  
A                         10.00 100.00   90.00   55.00  28.72   9    10.00
B                         10.00 100.00  -90.00   55.00  28.72   0      n/a 
     */
}
